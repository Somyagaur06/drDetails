
insert into dr_Pojo

(component_Name,dr_Number,environment,approval_Status,stories,release,notes,version)
values
('FOS%20SIL','39067','Dev2','Approved','ORCE-3376753343','R4500','Test DR staging Check','1.3.2'),

('supplierPortal','39070','Pluto','Approved','ORCE-776743','R4550','Test Test Check','1.3.2')

;

